create_clock -name clk -period 20.833333333333336 [get_ports {clk}]
