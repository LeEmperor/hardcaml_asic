module tt_um_asic_memory (
    ui_in,
    uio_in,
    ena,
    clk,
    rst_n,
    uo_out,
    uio_out,
    uio_oe
);

    input [7:0] ui_in;
    input [7:0] uio_in;
    input ena;
    input clk;
    input rst_n;
    output [7:0] uo_out;
    output [7:0] uio_out;
    output [7:0] uio_oe;

    wire [7:0] signal_const;
    wire signal_not;
    wire signal_and;
    wire [1:0] signal_const_2;
    wire signal_eq;
    wire signal_and_1;
    wire signal_and_2;
    reg [7:0] signal_reg;
    wire [1:0] signal_const_3;
    wire signal_eq_1;
    wire signal_and_3;
    wire signal_and_4;
    reg [7:0] signal_reg_1;
    wire [1:0] signal_const_4;
    wire signal_eq_2;
    wire signal_and_5;
    wire signal_and_6;
    reg [7:0] signal_reg_2;
    wire [1:0] signal_const_5;
    wire signal_eq_3;
    wire signal_select;
    wire signal_wire;
    wire signal_and_7;
    wire signal_and_8;
    wire signal_wire_1;
    wire [7:0] signal_wire_2;
    reg [7:0] signal_reg_3;
    wire [7:0] signal_wire_3;
    wire [1:0] signal_select_1;
    reg [7:0] signal_mux;
    reg [7:0] signal_reg_4;
    assign signal_const = 8'b00000000;
    assign signal_not = ~ signal_select;
    assign signal_and = signal_wire & signal_not;
    assign signal_const_2 = 2'b11;
    assign signal_eq = signal_select_1 == signal_const_2;
    assign signal_and_1 = signal_wire & signal_select;
    assign signal_and_2 = signal_and_1 & signal_eq;
    always @(posedge signal_wire_1) begin
        if (signal_and_2)
            signal_reg <= signal_wire_2;
    end
    assign signal_const_3 = 2'b10;
    assign signal_eq_1 = signal_select_1 == signal_const_3;
    assign signal_and_3 = signal_wire & signal_select;
    assign signal_and_4 = signal_and_3 & signal_eq_1;
    always @(posedge signal_wire_1) begin
        if (signal_and_4)
            signal_reg_1 <= signal_wire_2;
    end
    assign signal_const_4 = 2'b01;
    assign signal_eq_2 = signal_select_1 == signal_const_4;
    assign signal_and_5 = signal_wire & signal_select;
    assign signal_and_6 = signal_and_5 & signal_eq_2;
    always @(posedge signal_wire_1) begin
        if (signal_and_6)
            signal_reg_2 <= signal_wire_2;
    end
    assign signal_const_5 = 2'b00;
    assign signal_eq_3 = signal_select_1 == signal_const_5;
    assign signal_select = signal_wire_3[2:2];
    assign signal_wire = ena;
    assign signal_and_7 = signal_wire & signal_select;
    assign signal_and_8 = signal_and_7 & signal_eq_3;
    assign signal_wire_1 = clk;
    assign signal_wire_2 = uio_in;
    always @(posedge signal_wire_1) begin
        if (signal_and_8)
            signal_reg_3 <= signal_wire_2;
    end
    assign signal_wire_3 = ui_in;
    assign signal_select_1 = signal_wire_3[1:0];
    always @* begin
        case (signal_select_1)
        0:
            signal_mux <= signal_reg_3;
        1:
            signal_mux <= signal_reg_2;
        2:
            signal_mux <= signal_reg_1;
        default:
            signal_mux <= signal_reg;
        endcase
    end
    always @(posedge signal_wire_1) begin
        if (signal_and)
            signal_reg_4 <= signal_mux;
    end
    assign uo_out = signal_reg_4;
    assign uio_out = signal_const;
    assign uio_oe = signal_const;

endmodule
