module tt_um_asic_memory (
    ui_in,
    uio_in,
    ena,
    clk,
    rst_n,
    uo_out,
    uio_out,
    uio_oe
);

    input [7:0] ui_in;
    input [7:0] uio_in;
    input ena;
    input clk;
    input rst_n;
    output [7:0] uo_out;
    output [7:0] uio_out;
    output [7:0] uio_oe;

    wire [7:0] signal_const;
    wire [7:0] signal_const_2;
    wire signal_wire;
    wire signal_and;
    wire [7:0] signal_wire_1;
    wire signal_wire_2;
    reg [7:0] program_behavioral[0:3];
    wire [1:0] signal_select;
    wire [7:0] signal_mem_read_port;
    wire [7:0] signal_wire_3;
    wire signal_select_1;
    wire [7:0] signal_mux;
    reg [7:0] signal_reg;
    assign signal_const = 8'b00000000;
    assign signal_const_2 = 8'b01010101;
    assign signal_wire = ena;
    assign signal_and = signal_wire & signal_select_1;
    assign signal_wire_1 = uio_in;
    assign signal_wire_2 = clk;
    always @(posedge signal_wire_2) begin
        if (signal_and)
            program_behavioral[signal_select] <= signal_wire_1;
    end
    initial begin
        program_behavioral[0] <= 8'b01010101;
        program_behavioral[1] <= 8'b10101010;
        program_behavioral[2] <= 8'b01010101;
        program_behavioral[3] <= 8'b10101010;
    end
    assign signal_select = signal_wire_3[1:0];
    assign signal_mem_read_port = program_behavioral[signal_select];
    assign signal_wire_3 = ui_in;
    assign signal_select_1 = signal_wire_3[2:2];
    assign signal_mux = signal_select_1 ? signal_const_2 : signal_mem_read_port;
    always @(posedge signal_wire_2) begin
        if (signal_wire)
            signal_reg <= signal_mux;
    end
    assign uo_out = signal_reg;
    assign uio_out = signal_const;
    assign uio_oe = signal_const;

endmodule
