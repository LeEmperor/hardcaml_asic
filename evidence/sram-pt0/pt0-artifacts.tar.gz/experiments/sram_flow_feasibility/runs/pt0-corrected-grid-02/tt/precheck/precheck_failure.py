class PrecheckFailure(Exception):
    pass
